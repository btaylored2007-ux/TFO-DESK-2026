#!/usr/bin/env python3
"""Stage the crypto pre-pump hypothesis. Does not start a service or write a production tree."""
import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

BOOK = "veteran_desk/book.py"
BACKUP = "state/thf/crypto_prepump_20261107_backups"
_HERE = Path(__file__).resolve().parent
ROOT = _HERE / "payload" if (_HERE / "payload").is_dir() else _HERE.parents[1]
MANIFEST = json.loads((_HERE / "MANIFEST.json").read_text())
BOOK_SHA = MANIFEST["book_must_remain"]
BLOCKING = {"BLOCKED", "MISSING_PAYLOAD", "ABSENT_REFUSED", "BOOK_MISMATCH", "BOOK_ABSENT", "REFUSED_ROOT", "NEW_FILE_CONFLICT"}


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 16), b""):
            digest.update(chunk)
    return digest.hexdigest()


def production_root(path):
    text = str(Path(path).resolve())
    if (Path(path) / ".git").exists():
        return True
    for banned in ("/opt/tfo/live", "/opt/tfo/dash"):
        if text == banned or text.startswith(banned + "/"):
            return True
    return False


def _item(rel):
    for item in list(MANIFEST["payloads"]) + list(MANIFEST["new_files"]):
        if item["path"] == rel:
            return item
    return None


def plan(live_root):
    live = Path(live_root)
    if production_root(live):
        return [dict(path=str(live), state="REFUSED_ROOT", sha256=None)]
    rows = []
    book = live / BOOK
    if not book.is_file():
        rows.append(dict(path=BOOK, state="BOOK_ABSENT", sha256=None))
    else:
        digest = sha256(book)
        rows.append(dict(path=BOOK, state="ALREADY_PROTECTED" if digest == BOOK_SHA else "BOOK_MISMATCH", sha256=digest))
    for item in MANIFEST["payloads"]:
        src = ROOT / item["path"]
        payload = sha256(src) if src.is_file() else None
        if payload != item["target_sha256"]:
            rows.append(dict(path=item["path"], state="MISSING_PAYLOAD", sha256=payload))
            continue
        dest = live / item["path"]
        if not dest.is_file():
            rows.append(dict(path=item["path"], state="ABSENT_REFUSED", sha256=None))
            continue
        current = sha256(dest)
        state = "CURRENT" if current == payload else "REPLACE" if current == item["base_sha256"] else "BLOCKED"
        rows.append(dict(path=item["path"], state=state, sha256=current))
    for item in MANIFEST["new_files"]:
        src = ROOT / item["path"]
        payload = sha256(src) if src.is_file() else None
        if payload != item["target_sha256"]:
            rows.append(dict(path=item["path"], state="MISSING_PAYLOAD", sha256=payload))
            continue
        dest = live / item["path"]
        if not dest.exists():
            rows.append(dict(path=item["path"], state="INSTALL_NEW", sha256=None))
        else:
            current = sha256(dest)
            rows.append(dict(path=item["path"], state="CURRENT" if current == payload else "NEW_FILE_CONFLICT", sha256=current))
    return rows


def _restore(live, rel):
    backup = live / BACKUP / rel
    dest = live / rel
    if not backup.is_file():
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(backup, dest)
    return True


def apply_plan(live_root, rows):
    live = Path(live_root)
    apply_plan.last_error = None
    if any(row["state"] in BLOCKING for row in rows):
        return False
    done, rel = [], None
    try:
        for row in rows:
            if row["state"] not in ("REPLACE", "INSTALL_NEW"):
                continue
            rel = row["path"]
            item = _item(rel)
            dest = live / rel
            if row["state"] == "REPLACE":
                backup = live / BACKUP / rel
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, backup)
                if sha256(backup) != item["base_sha256"]:
                    raise RuntimeError("backup mismatch")
                try:
                    shutil.copy2(ROOT / rel, dest)
                    if sha256(dest) != item["target_sha256"]:
                        raise RuntimeError("target mismatch")
                except Exception:
                    if not _restore(live, rel):
                        raise RuntimeError("restore failed")
                    raise
                done.append(("replace", rel))
            else:
                if dest.exists():
                    raise RuntimeError("new file appeared")
                dest.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(ROOT / rel, dest)
                    if sha256(dest) != item["target_sha256"]:
                        raise RuntimeError("new file mismatch")
                except Exception:
                    if dest.is_file():
                        dest.unlink()
                    raise
                done.append(("new", rel))
    except Exception as error:
        for kind, name in reversed(done):
            if kind == "replace":
                _restore(live, name)
            elif (live / name).is_file():
                (live / name).unlink()
        apply_plan.last_error = "FAILED_COPY %s: %s" % (rel, error)
        return False
    return True


def main(argv=None):
    parser = argparse.ArgumentParser(description="Dry-run the crypto pre-pump package.")
    parser.add_argument("--root", required=True)
    parser.add_argument("--staging", action="store_true")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args(argv)
    if production_root(args.root):
        print("REFUSED_ROOT")
        print("NOT_DEPLOYED")
        return 2
    rows = plan(args.root)
    blocked = False
    for row in rows:
        print("%s %s" % (row["state"], row["path"]))
        if row["state"] in BLOCKING:
            blocked = True
    if args.apply:
        apply_plan.last_error = None
        if not args.staging or blocked or not apply_plan(args.root, rows):
            print("APPLY_REFUSED")
            if apply_plan.last_error:
                print(apply_plan.last_error)
            print("NOT_DEPLOYED")
            return 2
        print("STAGED")
    else:
        print("DRY_RUN")
    print("NOT_DEPLOYED")
    print("NOT_A_PROVEN_EDGE")
    return 3 if blocked else 0


if __name__ == "__main__":
    sys.exit(main())
