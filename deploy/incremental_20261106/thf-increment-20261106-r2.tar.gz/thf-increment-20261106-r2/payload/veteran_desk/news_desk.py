"""Veteran NEWS DESK (Brett 2026-10-28 17:01 WITA). Team: Quinn Mercer (chief), Ravi Sandhu (headline wire), Elena Park (macro/central banks),
Tom Barrett (geopolitics/energy shocks), Mara Quist (credit/stress). Code-only, free public feeds, PAPER. Outputs (info-only):
state/veteran_desk/news.json (regime flag, headlines, per-asset tags, positions at risk), news_alerts.jsonl, reports/veteran_desk/news_brief_<mkt>.md.
The regime flag may only TIGHTEN sizing in crisis (book.py halves risk); it never blocks Brett's tick. Delays: RSS 1-15 min, SEC 8-K atom ~minutes,
VIX/credit via Yahoo ~15 min delayed, FRED HY spread is previous-day."""
import urllib.parse, datetime as dt, email.utils, json, os, re, sys, urllib.request, xml.etree.ElementTree as ET
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); UTC = dt.timezone.utc; OUT = os.path.join(BASE, "state", "veteran_desk", "news.json")
ALERTS = os.path.join(BASE, "state", "veteran_desk", "news_alerts.jsonl"); UA = {"User-Agent": "TFO paper research brett-desk research@example.com"}
try: from veteran_desk import sec_forms as SF   # newstags_20261103 (F23): real SEC form type per entry; routine prospectus/shelf filings are not catalysts
except Exception: SF = None
TEAM = {"chief": "Quinn Mercer", "tech_desk_reader": "Nico Hart (reads)", "wire": "Ravi Sandhu", "macro": "Elena Park", "geo": "Tom Barrett", "credit": "Mara Quist"}
FEEDS = {"BBC Business": "https://feeds.bbci.co.uk/news/business/rss.xml", "CNBC": "https://www.cnbc.com/id/100003114/device/rss/rss.html",
         "MarketWatch": "https://feeds.content.dowjones.io/public/rss/mw_topstories", "Guardian Business": "https://www.theguardian.com/business/rss",
         "OilPrice": "https://oilprice.com/rss/main", "Federal Reserve": "https://www.federalreserve.gov/feeds/press_all.xml", "ECB": "https://www.ecb.europa.eu/rss/press.html",
         "RBA": "https://www.rba.gov.au/rss/rss-cb-media-releases.xml", "SEC 8-K": "https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&type=8-K&count=40&output=atom",
         "CoinDesk": "https://www.coindesk.com/arc/outboundfeeds/rss", "SEC Form 4": "https://www.sec.gov/cgi-bin/browse-edgar?action=getcurrent&type=4&count=40&output=atom", "DCD (datacentre)": "https://www.datacenterdynamics.com/en/rss/"}
NOT_WIRED = {"ASX announcements": "live path is catalyst_stream (com.tfo.catalyst-stream); this 15-min job keeps the regime flag",
             "LSE RNS": "live path is catalyst_stream via the Investegate RNS RSS",
             "HKEX": "live path is catalyst_stream (HKEX disclosure feed, best effort)",
             "JPX/TDnet": "live path is catalyst_stream (public TDnet mirror)",
             "economic calendar": "live path is catalyst_stream: FMP calendar primary, Fed/CB RSS and the macro file as fallback"}
DESK = {"macro": r"\b(fed|fomc|ecb|rba|boj|rate (cut|hike)|cpi|inflation|payrolls|jobs report|gdp|central bank|powell|lagarde|bullock|treasury yields?)\b",
        "geo": r"\b(war|missile|strike|sanction|opec|tariff|houthi|red sea|strait|shipping|pipeline|iran|russia|ukraine|israel|embargo)\b",
        "credit": r"\b(default|downgrade|credit spread|bankrupt|chapter 11|liquidity|bank run|margin call|vix|selloff|sell-off|crash|private credit|neocloud|coreweave|nebius|notes offering|convertible notes|credit facility|debt raise|gpu-backed|data center financing)\b"}
ASSET_KW = {"XOM": "exxon", "CVX": "chevron", "COP": "conocophillips", "OXY": "occidental", "WDS.AX": "woodside", "STO.AX": "santos", "JPM": "jpmorgan", "BAC": "bank of america",
            "WFC": "wells fargo", "C": "citigroup", "CBA.AX": "commonwealth bank", "WBC.AX": "westpac", "NAB.AX": "national australia bank", "ANZ.AX": r"\banz\b", "JNJ": "johnson & johnson",
            "UNH": "unitedhealth", "LLY": "eli lilly", "PFE": "pfizer", "MRK": "merck", "CSL.AX": r"\bcsl\b", "PG": "procter", "KO": "coca-cola", "WMT": "walmart", "WOW.AX": "woolworths",
            "CL=F": r"\b(oil|crude|brent|wti|opec)\b", "BZ=F": r"\b(brent|opec)\b", "NG=F": r"natural gas|\blng\b", "GC=F": r"\bgold\b", "AUDUSD=X": r"aussie dollar|\brba\b|australian dollar",
            "USDJPY=X": r"\byen\b|\bboj\b", "EURUSD=X": r"\becb\b|\beuro\b", "KRAKEN:XBTUSD": r"bitcoin|\bbtc\b", "KRAKEN:ETHUSD": r"ether(eum)?\b", "KRAKEN:SOLUSD": r"solana", "NVDA": r"nvidia", "AMD": r"\bamd\b", "AVGO": r"broadcom", "MSFT": r"microsoft", "META": r"\bmeta\b", "ORCL": r"oracle", "CRWV": r"coreweave", "NBIS": r"nebius", "SMCI": r"super micro", "MU": r"micron", "TSM": r"tsmc|taiwan semi", "GOOGL": r"alphabet|google", "AMZN": r"amazon|\baws\b"}
MARKETS = {"US": r"wall street|s&p|nasdaq|\bdow\b|\bfed\b|u\.s\.", "ASX": r"australia|asx|rba", "JP": r"japan|nikkei|boj|yen", "HK": r"hong kong|hang seng|china", "LSE": r"london|ftse|\bboe\b|britain|\buk\b", "CRYPTO": r"bitcoin|crypto|ether"}
A = "{http://www.w3.org/2005/Atom}"
def _get(u, t=12):
    from veteran_desk import feeds as _F   # follows 307/308 on py3.9
    return _F._OPENER.open(urllib.request.Request(u, headers=UA), timeout=t).read()
def now(): return dt.datetime.now(UTC)
def _ts(s):
    try: d = email.utils.parsedate_to_datetime(s); return d.astimezone(UTC) if d.tzinfo else d.replace(tzinfo=UTC)
    except Exception:
        try: return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone(UTC)
        except Exception: return None
def _paid_news(health):
    """tfo_newspaid_20261030 (Brett HARD RULE 21:41): paid news PRIMARY - Massive/Benzinga, EODHD news, FMP news. Each headline source-tagged."""
    H = []
    try:
        from veteran_desk import massive as _MS
        _mn = _MS.news(limit=25); H += [dict(h, feed_source="massive/" + str(h.get("source") or "benzinga"), source=h.get("source") or "Benzinga", published_utc=_ts(h["published_utc"]).isoformat()) for h in _mn if _ts(h["published_utc"])]
        health["massive"] = "ok" if _mn else "empty/not entitled"
    except Exception as e: health["massive"] = "fail: " + str(e)[:60]
    try:
        from veteran_desk import data_layer as _DL
        js = _DL.call("news", "/news", {"t": "markets", "limit": 30}); n = 0
        for r in js if isinstance(js, list) else []:
            p = _ts(str(r.get("date") or ""))
            if r.get("title") and p: H.append(dict(title=r["title"][:220], link=r.get("link") or "", source="EODHD news", feed_source="eodhd_news", published_utc=p.isoformat(), tickers=r.get("symbols") or r.get("tickers") or [])); n += 1
        health["eodhd_news"] = "ok" if n else "empty"
    except Exception as e: health["eodhd_news"] = "fail: " + str(e)[:60]
    try:
        from veteran_desk import thf_paid_pack as _PP
        k = _PP._key("fmp", "FMP_API_KEY"); n = 0
        js = _PP._get("fmp_news", "https://financialmodelingprep.com/stable/news/general-latest?page=0&limit=30&apikey=" + urllib.parse.quote(k)) if k else None
        for r in js if isinstance(js, list) else []:
            pd_ = str(r.get("publishedDate") or ""); p = _ts(pd_.replace(" ", "T") + ("" if ("+" in pd_ or pd_.endswith("Z")) else "+00:00"))   # FMP naive stamp read as UTC
            if r.get("title") and p: H.append(dict(title=r["title"][:220], link=r.get("url") or "", source="FMP / " + str(r.get("publisher") or r.get("site") or "news"), feed_source="fmp_news", published_utc=p.isoformat(), tickers=r.get("symbol") or [])); n += 1
        health["fmp_news"] = "ok" if n else "empty"
    except Exception as e: health["fmp_news"] = "fail: " + str(e)[:60]
    return H
def _sec_tag(h, it, feed):
    """newstags_20261103 (F23): EDGAR getcurrent 'type=' is a PREFIX filter - the 'SEC Form 4' feed also returns 424B2/424B3/425/497 ... and
    every entry carried the feed name as its source. Now: source = the entry's own form ('SEC Form 4' only for 4 and 4/A) + form/accession;
    routine prospectus/shelf paperwork -> catalyst False (veteran_desk/sec_forms.py). Unreadable form -> kept as news (old behaviour) + warning."""
    C = SF.classify(SF.atom_form(it, h["title"]), title=h["title"])
    h.update(source=C["label"], sec_feed=feed, form=C["form"] or "unknown", accession=SF.accession(h.get("link")), catalyst=C["catalyst"])
    if not C["catalyst"]: h.update(routine=C["routine"],non_catalyst_why=C["why"],amendment=C.get("amendment",False))
    if not C["form"]: print("news_desk WARNING newstags_20261103: SEC item from '%s' has no readable form type, kept as news: %s" % (feed, h["title"][:120]), file=sys.stderr)
    return h
def headlines():
    H, health = [], {}
    H += _paid_news(health)
    for src, u in FEEDS.items():   # free RSS/public: fallback + official sources (Fed/ECB/RBA/SEC), tagged rss_fallback
        try:
            root = ET.fromstring(_get(u)); n = 0
            for it in list(root.iter("item")) + list(root.iter(A + "entry")):
                ti = (it.findtext("title") or it.findtext(A + "title") or "").strip(); le = it.find(A + "link")
                ln = it.findtext("link") or (le.get("href") if le is not None else "")
                pub = _ts(it.findtext("pubDate") or it.findtext(A + "updated") or "")
                if ti and pub:
                    H.append(dict(title=ti[:220], link=(ln or "").strip(), source=src, feed_source="rss_fallback", published_utc=pub.isoformat())); n += 1
                    if SF and src.startswith("SEC "): _sec_tag(H[-1], it, src)   # newstags_20261103: label by the entry's own form type, not the feed name
                if n >= 25: break
            health[src] = "ok"
        except Exception as e: health[src] = "fail: " + str(e)[:60]
    for h in H: h["available_at_utc"] = now().isoformat()
    cut = now() - dt.timedelta(hours=36); H = [h for h in H if dt.datetime.fromisoformat(h["published_utc"]) >= cut]
    for h in H:
        from veteran_desk.headline_subject import subject
        attribution=subject(h["title"],ASSET_KW,h.get("tickers") or h.get("symbol") or [])
        t=attribution["subject_text"].lower()
        h["desk"]=[k for k,r in DESK.items() if re.search(r,t)] or ["wire"];h["owner"]=TEAM[h["desk"][0]]
        h["assets"]=list(dict.fromkeys(attribution["tickers"]+[a for a,r in ASSET_KW.items() if re.search(r,t)]))
        h["markets"]=[market for market,pattern in MARKETS.items() if re.search(pattern,t)]
        if attribution["broker_rating"]:h["rating_attribution"]=attribution
        h["score"] = 2 * len(h["assets"]) + (3 if "credit" in h["desk"] else 0) + (2 if "geo" in h["desk"] else 0) + (1 if "macro" in h["desk"] else 0)
        if h.get("routine") or h.get("catalyst") is False:   # newstags_20261103: routine SEC paperwork never tags an asset/market -> no asset_tags, news hit, top5 crypto tag, alert or rail input; kept in news.json routine_filings
            h["non_catalyst_why"] = SF.routine_reason(h.get("form"), (h["assets"] or [None])[0], h["title"]) or h.get("non_catalyst_why")
            h["filing_assets"], h["assets"], h["markets"], h["score"] = h["assets"], [], [], -1
    H.sort(key=lambda h: (h["score"], h.get("feed_source") != "rss_fallback", h["published_utc"]), reverse=True); return H, health
REGIME_REQUIRED = ("vix", "spx_5d_pct", "spx_efficiency20", "hyg_lqd_20d_pct", "hy_oas_pct")
def _closes(yf, s):   # tfo_seatpipe_regimefb_20261030: yfinance empty/429 -> direct Yahoo chart v8 (pit.yahoo_chart) closes
    try: c = yf.Ticker(s).history(period="2mo").Close; assert len(c) > 21; return c
    except Exception:
        if os.environ.get("PYTEST_CURRENT_TEST"): raise
        import pandas as pd; from veteran_desk import pit as _P; return pd.Series([r[4] for r in _P.yahoo_chart(s, "3mo")])
def regime():
    try: import yfinance as yf
    except Exception: yf = None   # import failure -> every price input missing -> unknown
    g = {}
    try: v = yf.Ticker("^VIX").history(period="5d"); g["vix"] = round(float(v.Close.iloc[-1]), 2)
    except Exception: pass
    if "vix" not in g:   # yfinance empty -> FRED VIXCLS (prior-day close)
        try:
            from veteran_desk import feeds as _F; d, v = _F.fred_last("VIXCLS"); g["vix"] = round(v, 2); g["vix_src"] = "fred:VIXCLS " + d
        except Exception: pass
    try:
        s = _closes(yf, "^GSPC"); g["spx_5d_pct"] = round(float(s.iloc[-1] / s.iloc[-6] - 1) * 100, 2)
        g["spx_efficiency20"] = round(float(abs(s.iloc[-1] - s.iloc[-21]) / (s.diff().abs().iloc[-20:].sum() or 1)), 3)
    except Exception: pass
    try: h = _closes(yf, "HYG"); l = _closes(yf, "LQD"); r = h / l; g["hyg_lqd_20d_pct"] = round(float(r.iloc[-1] / r.iloc[-21] - 1) * 100, 2)
    except Exception: pass
    try:
        txt = _get("https://fred.stlouisfed.org/graph/fredgraph.csv?id=BAMLH0A0HYM2").decode().strip().splitlines()
        last = [x for x in txt[1:] if x.split(",")[1] not in (".", "")][-1].split(","); g["hy_oas_pct"] = float(last[1]); g["hy_oas_date"] = last[0]
    except Exception: pass
    miss = [k for k in REGIME_REQUIRED if g.get(k) is None]   # FAIL-SAFE (TFO HT 22:55): any missing input -> 'unknown', never a defaulted 'calm'
    if miss: g["missing"] = miss; return "unknown", g
    V, M, O, C, E = g["vix"], g["spx_5d_pct"], g["hy_oas_pct"], g["hyg_lqd_20d_pct"], g["spx_efficiency20"]
    if V > 35 or O > 6.5 or M < -8: return "crisis", g
    if V > 25 or O > 5 or M < -4 or C < -2: return "risk-off", g
    if V > 18 or E < .25: return "choppy", g
    return "calm", g
def held_positions():
    try: D = json.load(open(os.path.join(BASE, "reports", "veteran_desk_book.json")))
    except Exception: return []
    return [dict(p, seat=k) for k, S in (D.get("seats") or {}).items() for p in S.get("positions", {}).values()]
def run():
    H, health = headlines(); flag, gauges = regime(); held = held_positions(); tags = {}
    for h in H:
        for a in h["assets"]: tags.setdefault(a, []).append(dict(title=h["title"], source=h["source"], link=h["link"], published_utc=h["published_utc"], desk=h["desk"], **({"form": h["form"]} if h.get("form") else {})))   # newstags_20261103: + SEC form
    routine = {}   # newstags_20261103 (F23): routine SEC filings per asset - visible + labelled, never a catalyst (not in asset_tags / at_risk / news_alerts)
    for h in H:
        for a in h.get("filing_assets") or []: routine.setdefault(a, []).append(dict(title=h["title"], source=h["source"], form=h.get("form"), link=h["link"], published_utc=h["published_utc"], catalyst=False, why=h.get("non_catalyst_why")))
    at_risk = [dict(seat=p["seat"], ticker=p["ticker"], side=p["side"], headlines=tags[p["ticker"]][:3]) for p in held if p["ticker"] in tags]
    prev = set()
    try: prev = set(json.load(open(OUT)).get("alerted", []))
    except Exception: pass
    new = [(r["ticker"], h["title"]) for r in at_risk for h in r["headlines"] if (r["ticker"] + h["title"]) not in prev]
    os.makedirs(os.path.dirname(ALERTS), exist_ok=True)
    with open(ALERTS, "a") as f:
        for t, ti in new: f.write(json.dumps(dict(utc=now().isoformat(), ticker=t, headline=ti, urgent=True)) + "\n")
    out = dict(updated_utc=now().isoformat(), team=TEAM, regime=dict(flag=flag, gauges=gauges, owner=TEAM["credit"], sizing_effect="crisis halves new-trade risk (Marcus enforces); never blocks a tick"),
               top5=H[:5], headlines=H[:60], asset_tags=tags, routine_filings={a: dict(n=len(v), forms=sorted({str(x["form"]) for x in v}), newest_utc=max(x["published_utc"] for x in v), note="routine SEC paperwork: not a catalyst, not a news hit, no alert/rail input (newstags_20261103)", items=v[:3]) for a, v in routine.items()}, positions_at_risk=at_risk, alerted=sorted(prev | {t + ti for t, ti in new}), new_alerts=new,
               feed_health=health, not_wired=NOT_WIRED, delays="RSS 1-15 min; SEC 8-K minutes; VIX/credit ETFs ~15 min (Yahoo); FRED HY spread prior day", info_only=True)
    d = os.path.join(BASE, "reports", "veteran_desk"); os.makedirs(d, exist_ok=True)
    for m in MARKETS:
        L = [h for h in H if m in h["markets"]][:8]
        open(os.path.join(d, f"news_brief_{m}.md"), "w").write(f"# {m} pre-open news brief - {TEAM['chief']} (regime: {flag})\n\n" + ("\n".join(f"- [{h['source']}] {h['title']} ({h['published_utc'][:16]}Z) {h['link']}" for h in L) or "- nothing market-specific"))
    t = OUT + ".tmp"; json.dump(out, open(t, "w"), indent=1); os.replace(t, OUT); return out
if __name__ == "__main__":
    o = run(); print(o["regime"]["flag"], o["regime"]["gauges"], len(o["headlines"]), {k: v for k, v in o["feed_health"].items() if v != "ok"})
